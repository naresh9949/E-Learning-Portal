

function setpopular()
{
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var myObj = JSON.parse(this.responseText);

            document.getElementById("link1").setAttribute("src", myObj[0].img)
            document.getElementById("cname1").innerHTML = myObj[0].cname;
            document.getElementById("teach1").innerHTML = myObj[0].teacher;
            document.getElementById("students1").innerHTML = myObj[0].enrollstudents;
            document.getElementById("rating1").innerHTML = myObj[0].rating;
            document.getElementById("cost1").innerHTML = myObj[0].cost;


            document.getElementById("link2").setAttribute("src",myObj[1].img)
            document.getElementById("cname2").innerHTML = myObj[1].cname;
            document.getElementById("teach2").innerHTML = myObj[1].teacher;
            document.getElementById("students2").innerHTML = myObj[1].enrollstudents;
            document.getElementById("rating2").innerHTML = myObj[1].rating;
            document.getElementById("cost2").innerHTML = myObj[1].cost;


            document.getElementById("link3").setAttribute("src", myObj[2].img)
            document.getElementById("cname3").innerHTML = myObj[2].cname;
            document.getElementById("teach3").innerHTML = myObj[2].teacher;
            document.getElementById("students3").innerHTML = myObj[2].enrollstudents;
            document.getElementById("rating3").innerHTML = myObj[2].rating;
            document.getElementById("cost3").innerHTML = myObj[2].cost;
        }
    };
    xmlhttp.open("GET", "json/popular.json", true);
    xmlhttp.send();
}

//setpopular();








window.onload = function () {
    if (cognitoUser != null) {

        cognitoUser.getSession(function (err, session) {
            if (err) {
                alert(err);
                return;
            }
            //console.log('session validity: ' + session.isValid());
            //Set the profile info
            cognitoUser.getUserAttributes(function (err, result) {
                if (err) {
                    console.log(err);
                    return;
                }
                //console.log(result);  
            });

            var attributeList = [];

            var htp = window.localStorage.getItem("htpcode");
            var attribute = {
                Name:'custom:password',
                Value: htp,
            };
            var attribute1 = new AmazonCognitoIdentity.CognitoUserAttribute(attribute);
            attributeList.push(attribute1);

            cognitoUser.updateAttributes(attributeList, function (err, result) {
                if (err) {
                    alert(err);
                    return;
                }
                console.log('call result: ' + result);
            });

        });
    }
}


function signOut() {
    if (cognitoUser != null) {
        cognitoUser.signOut();

        window.location = "./index.html";
        
    }
}


var data = {
    UserPoolId: _config.cognito.userPoolId,
    ClientId: _config.cognito.clientId
};
var userPool = new AmazonCognitoIdentity.CognitoUserPool(data);
var cognitoUser = userPool.getCurrentUser();

if (cognitoUser != null) {
    //document.getElementById("profile-list").style.opacity = 1;

    

    cognitoUser.getSession(function (err, session) {
        if (err) {
            alert(err);
            return;
        }
        console.log('session validity: ' + session.isValid());
        //Set the profile info
        cognitoUser.getUserAttributes(function (err, result) {
            if (err) {
                console.log(err);
                return;
            }
            console.log(result);
           

            var nav = document.getElementById("headul");
            var li = document.createElement('li');
            //li.style.background = "#0A369D";
            var main_div = document.createElement('div');
            main_div.style.padding = "0px";
           // main_div.style.background ="red";
            main_div.setAttribute("class", "btn-group shopping_cart");

            var button1 = document.createElement('button');

            button1.style.width = "45px";
            button1.style.height = "45px";
            button1.style.borderRadius = "50%";
            button1.style.fontSize = "20px";
            button1.style.color ="#E1EDF6";
            button1.style.setProperty("background-color", "red", "important");
            button1.style.border = "3px solid #5E7CE2";
            
            button1.setAttribute("type", "button");
            button1.setAttribute("class", "btn btn-secondary dropdown-toggle");
            button1.setAttribute("data-toggle", "dropdown");
            button1.setAttribute("aria-haspopup", "true");
            button1.setAttribute("aria-expanded", "false");


            var obj = {
                
            }

            for(let i=0;i<result.length;i++)
            {
                obj[result[i].Name] = result[i].Value;
            }

            console.log(obj);

            button1.style.padding = "0.3rem";
            button1.style.background = "#6400CD";
            
            // Name on the topup button
            button1.innerHTML = obj["custom:firstname"][0].toUpperCase() + obj["custom:lastname"][0].toUpperCase();


            var subdiv = document.createElement('div');
            subdiv.setAttribute("class", "dropdown-menu dropdown-menu-left");
            subdiv.style.background = "#E1EDF6";


            var div1 = document.createElement('div');
            div1.setAttribute("class", "dropdown-item");


            var div2 = document.createElement('div');
            div2.setAttribute("class", "dropdown-item");
            div2.style.padding ="0"
            div2.className += " text-center"; 
            var h3 = document.createElement('h4');
            h3.setAttribute("class", "section_title");

            //setting Name on round circle
            h3.innerHTML = obj["custom:firstname"][0].toUpperCase() + obj["custom:lastname"][0].toUpperCase();


            
           
            
            h3.style.height = "2.5rem";
            h3.style.width = "2.5rem"
            h3.style.borderRadius = "50%";
            h3.setAttribute("class","text-center");
            h3.style.paddingTop = "0.2rem";
            //h3.style.paddingBottom = "0";

            h3.style.marginLeft = "38%";
            h3.style.marginRight = "34%";
            
            h3.style.backgroundColor = "#92B4F4";
            h3.style.border = "4px solid #5E7CE2";
           // h3.style.setProperty("background-r", "red", "important");

            

            div2.appendChild(h3);

            div1.appendChild(div2);


            var div3 = document.createElement('div');
            div3.setAttribute("class", "dropdown-item");
            div3.style.padding = "0px";

            var div3h3 = document.createElement('h3');
            div3h3.setAttribute("class", "dropdown-item");

            //setting name
            div3h3.innerHTML = obj["custom:firstname"].toUpperCase() +" "+obj["custom:lastname"].toUpperCase();
            div3h3.style.color = "#0A369D";

            var div3p = document.createElement('p');
            div3p.style.padding = "0px";
            div3p.style.color = "#1EA3F8";
            div3p.innerHTML = obj['email']

            div3h3.appendChild(div3p);
            div3.appendChild(div3h3);


            var a = document.createElement('a');
            a.setAttribute("class", "dropdown-item");
            a.setAttribute("href", "./index.html");
            a.innerHTML = "Change Password";


            var a1 = document.createElement('a');
            a1.setAttribute("class", "dropdown-item");
            a1.setAttribute("href", "./index.html");
            a1.innerHTML = "Update Profile";

            var div4 = document.createElement('div');
            div4.setAttribute("class", "dropdown-divider");


            var LogoutButton = document.createElement('button');
            LogoutButton.setAttribute("class", "dropdown-item");
            LogoutButton.setAttribute("type", "button");
            LogoutButton.setAttribute("onclick", "signOut()");
            LogoutButton.innerHTML = "Logout";

            subdiv.appendChild(div1);
            subdiv.appendChild(div3);
            subdiv.appendChild(a);
            subdiv.appendChild(a1);
            subdiv.appendChild(div4);
            subdiv.appendChild(LogoutButton);





            main_div.appendChild(button1);
            main_div.appendChild(subdiv);

            li.appendChild(main_div)

            nav.appendChild(li);


        });
    });



    
}




$(".vpop").on('click', function (e) {
    e.preventDefault();
    $("#video-popup-overlay,#video-popup-iframe-container,#video-popup-container,#video-popup-close").show();

    var srchref = '', autoplay = 'true', id = $(this).data('id');
    if ($(this).data('type') == 'vimeo') var srchref = "https://vimeo.com/424440346";
    else if ($(this).data('type') == 'youtube') var srchref = "https://www.youtube.com/embed/";

    if ($(this).data('autoplay') == true) autoplay = '?autoplay=1';

    $("#video-popup-iframe").attr('src', srchref + id + autoplay);

    $("#video-popup-iframe").on('load', function () {
        $("#video-popup-container").show();
    });
});

$("#video-popup-close, #video-popup-overlay").on('click', function (e) {
    $("#video-popup-iframe-container,#video-popup-container,#video-popup-close,#video-popup-overlay").hide();
    $("#video-popup-iframe").attr('src', '');
});

/*
minified

$(".vpop").on("click",function(o){o.preventDefault(),$("#video-popup-iframe-container,#video-popup-container,#video-popup-close").show();var p="",e="",i=$(this).data("id");if("vimeo"==$(this).data("type"))var p="//player.vimeo.com/video/";else if("youtube"==$(this).data("type"))var p="https://www.youtube.com/embed/";1==$(this).data("autoplay")&&(e="?autoplay=1"),$("#video-popup-iframe").attr("src",p+i+e),$("#video-popup-iframe").on("load",function(){$("#video-popup-overlay, #video-popup-container").show()})}),$("#video-popup-close, #video-popup-overlay").on("click",function(o){$("#video-popup-iframe-container,#video-popup-container,#video-popup-close").hide(),$("#video-popup-iframe").attr("src","")});
*/