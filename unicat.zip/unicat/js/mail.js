function sendEmail() {
    Email.send({
        Host: "smtp.gmail.com",
        Username: "utpadd.info@gmail.com",
        Password: "123@Utpadd",
        To: 'nareshkollipora9949@gmail.com',
        From: "utpadd.info@gmail.com",
        Subject: "Check",
        Body: "checked OK",
    }).then(
        message => alert("mail sent successfully")
    );
}