
var username;
var password;
var personalname;
var poolData;

function registerButton() {

    personalnamename = document.getElementById("personalnameRegister").value;
    username = document.getElementById("emailInputRegister").value;

    var mobileno = "+91" + document.getElementById("mobile").value;

    var fname = document.getElementById("personalnameRegister").value;

    var lname = document.getElementById("lname").value;

    var clg = document.getElementById("collage");

    var clgg="";

    var opt;
    for (var i = 0; i < clg.options.length; i++) {
        opt = clg.options[i];
        if (opt.selected === true) {
            clgg = opt.innerHTML;
            break;
        }
    }


    var pas = document.getElementById("passwordInputRegister").value;


    if (document.getElementById("passwordInputRegister").value != document.getElementById("confirmationpassword").value) {
        alert("Passwords Do Not Match!")
        throw "Passwords Do Not Match!"
    } else {
        password = document.getElementById("passwordInputRegister").value;
    }



    poolData = {
        UserPoolId: _config.cognito.userPoolId, // Your user pool id here
        ClientId: _config.cognito.clientId // Your client id here
    };


    var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);


    var attributeList = [];

    var dataEmail = {
        Name: 'email',
        Value: username, //get from form field
    };

    var dataPersonalName = {
        Name: 'name',
        Value: personalname, //get from form field
    };

    var Mobileno = {
        Name: 'phone_number',
        Value: mobileno,
    };


    datafirstname = {
        Name: 'custom:firstname',
      Value: fname, //get from form field
    };

    datalastname = {
        Name: 'custom:lastname',
        Value: lname, //get from form field
    };


    dataclg = {
        Name: 'custom:collage',
        Value: clgg, //get from form field
    };


    datapass = {
        Name: 'custom:password',
        Value: pas, //get from form field
    };


    var attributeEmail = new AmazonCognitoIdentity.CognitoUserAttribute(dataEmail);

    var attributePersonalName = new AmazonCognitoIdentity.CognitoUserAttribute(dataPersonalName);

    var Mobile = new AmazonCognitoIdentity.CognitoUserAttribute(Mobileno);

    var firstname = new AmazonCognitoIdentity.CognitoUserAttribute(datafirstname);

    var lastname = new AmazonCognitoIdentity.CognitoUserAttribute(datalastname);


    var clgname = new AmazonCognitoIdentity.CognitoUserAttribute(dataclg);

    var passi = new AmazonCognitoIdentity.CognitoUserAttribute(datapass);


    attributeList.push(attributeEmail);
    attributeList.push(attributePersonalName);
    attributeList.push(Mobile);
    attributeList.push(firstname);

    attributeList.push(lastname);
    attributeList.push(clgname);
    attributeList.push(passi);

    userPool.signUp(username, password, attributeList, null, function (err, result) {
        if (err) {
            alert(err.message || JSON.stringify(err));
            return;
        }
        cognitoUser = result.user;
        console.log('user name is ' + cognitoUser.getUsername());
        //change elements of page

        var head1 = document.getElementById("titleheader");
        head1.style.color = "red";
        head1.innerHTML = "Check your email for a verification link";

        document.getElementById("titleheader2").innerHTML = "Thank you for choseing us Happy Learning"

    });
}