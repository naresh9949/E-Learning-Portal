/* JS Document */

/******************************

[Table of Contents]

1. Vars and Inits
2. Set Header
3. Init Menu
4. Init Header Search
5. Init Tabs
6. Init Accordions
7. Init Dropdowns


******************************/

$(document).ready(function()
{
	"use strict";

	/* 

	1. Vars and Inits

	*/

	var header = $('.header');
	var menuActive = false;
	var menu = $('.menu');
	var burger = $('.hamburger');

	setHeader();

	$(window).on('resize', function()
	{
		setHeader();
	});

	$(document).on('scroll', function()
	{
		setHeader();
	});

	initMenu();
	initHeaderSearch();
	initTabs();
	initAccordions();
	initDropdowns();

	/* 

	2. Set Header

	*/

	function setHeader()
	{
		if($(window).scrollTop() > 100)
		{
			header.addClass('scrolled');
		}
		else
		{
			header.removeClass('scrolled');
		}
	}

	/* 

	3. Init Menu

	*/

	function initMenu()
	{
		if($('.menu').length)
		{
			var menu = $('.menu');
			if($('.hamburger').length)
			{
				burger.on('click', function()
				{
					if(menuActive)
					{
						closeMenu();
					}
					else
					{
						openMenu();

						$(document).one('click', function cls(e)
						{
							if($(e.target).hasClass('menu_mm'))
							{
								$(document).one('click', cls);
							}
							else
							{
								closeMenu();
							}
						});
					}
				});
			}
		}
	}

	function openMenu()
	{
		menu.addClass('active');
		menuActive = true;
	}

	function closeMenu()
	{
		menu.removeClass('active');
		menuActive = false;
	}

	/* 

	4. Init Header Search

	*/

	function initHeaderSearch()
	{
		if($('.search_button').length)
		{
			$('.search_button').on('click', function()
			{
				if($('.header_search_container').length)
				{
					$('.header_search_container').toggleClass('active');
				}
			});
		}
	}

	/* 

	5. Init Tabs

	*/

	function initTabs()
	{
		if($('.tab').length)
		{
			$('.tab').on('click', function()
			{
				$('.tab').removeClass('active');
				$(this).addClass('active');
				var clickedIndex = $('.tab').index(this);

				var panels = $('.tab_panel');
				panels.removeClass('active');
				$(panels[clickedIndex]).addClass('active');
			});
		}
	}

	/* 

	6. Init Accordions

	*/

	function initAccordions()
	{
		if($('.accordion').length)
		{
			var accs = $('.accordion');

			accs.each(function()
			{
				var acc = $(this);

				if(acc.hasClass('active'))
				{
					var panel = $(acc.next());
					var panelH = panel.prop('scrollHeight') + "px";
					
					if(panel.css('max-height') == "0px")
					{
						panel.css('max-height', panel.prop('scrollHeight') + "px");
					}
					else
					{
						panel.css('max-height', "0px");
					} 
				}

				acc.on('click', function()
				{
					if(acc.hasClass('active'))
					{
						acc.removeClass('active');
						var panel = $(acc.next());
						var panelH = panel.prop('scrollHeight') + "px";
						
						if(panel.css('max-height') == "0px")
						{
							panel.css('max-height', panel.prop('scrollHeight') + "px");
						}
						else
						{
							panel.css('max-height', "0px");
						} 
					}
					else
					{
						acc.addClass('active');
						var panel = $(acc.next());
						var panelH = panel.prop('scrollHeight') + "px";
						
						if(panel.css('max-height') == "0px")
						{
							panel.css('max-height', panel.prop('scrollHeight') + "px");
						}
						else
						{
							panel.css('max-height', "0px");
						} 
					}
				});
			});
		}
	}

	/* 

	7. Init Dropdowns

	*/

	function initDropdowns()
	{
		if($('.dropdowns li').length)
		{
			var dropdowns = $('.dropdowns li');

			dropdowns.each(function()
			{
				var dropdown = $(this);
				if(dropdown.hasClass('has_children'))
				{
					if(dropdown.hasClass('active'))
					{
						var panel = $(dropdown.find('> ul'));
						var panelH = panel.prop('scrollHeight') + "px";

						if(panel.css('max-height') == "0px")
						{
							panel.css('max-height', panel.prop('scrollHeight') + "px");
						}
						else
						{
							panel.css('max-height', "0px");
						}
					}

					dropdown.find(' > .dropdown_item').on('click', function()
					{
						var panel = $(dropdown.find('> ul'));
						var panelH = panel.prop('scrollHeight') + "px";
						dropdown.toggleClass('active');

						if(panel.css('max-height') == "0px")
						{
							panel.css('max-height', panel.prop('scrollHeight') + "px");
						}
						else
						{
							panel.css('max-height', "0px");
						}
					});
				}
			});
		}
	}

});











function SetVideoPlayList() {

	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function () {
		if (this.readyState == 4 && this.status == 200) {
			var myObj = JSON.parse(this.responseText);

		//console.log(myObj);
			
			var main_div = document.getElementById("accordion");

			for(let j=0;j<2;j++){

			var main_lecture_div = document.createElement('div');

			main_lecture_div.setAttribute("class","panel panel-default");
			
			var sub_div1 = document.createElement('div');
			sub_div1.setAttribute("class","panel-heading");
			sub_div1.setAttribute("role","tab");
			sub_div1.setAttribute("id","heading" + myObj[j].unitno);

			var h4 = document.createElement('h4');
			h4.setAttribute("class","panel-title size-1");
		
			var a = document.createElement('a');
			a.setAttribute("role","button");
			a.setAttribute("data-toggle", "collapse");
			a.setAttribute("data-parent", "#accordion");
			a.setAttribute("href", "#collapse" + myObj[j].unitno);
			a.setAttribute("aria-expanded","true");
			a.setAttribute("aria-controls", "collapse" + myObj[j].unitno);
			a.setAttribute("class","border border-primary black-text");
				a.innerHTML = "Unit " + myObj[j].unitno + " " + myObj[j].unit_title;

			h4.appendChild(a);
			sub_div1.appendChild(h4);
			main_lecture_div.appendChild(sub_div1);



			var colldiv = document.createElement('div');
			colldiv.setAttribute("id","collapse"+myObj[j].unitno);
			colldiv.setAttribute("class", "panel-collapse collapse in");
			colldiv.setAttribute("role", "tabpanel");
			colldiv.setAttribute("aria-labelledby", "heading" +myObj[j].unitno)

			var colldiv1 = document.createElement('div');
			colldiv1.setAttribute("class","panel-body");


			var colldiv2 = document.createElement('div');
			colldiv2.setAttribute("class", "bs-example");


			var colldiv3 = document.createElement('div');
			colldiv3.setAttribute("class", "list-group");


			for(let i=0;i<2;i++){

			var button = document.createElement('button');
			button.setAttribute("class","list-group-item list-group-item-action");
			

			var i1 = document.createElement('i');
			i1.setAttribute("class","fa fa-film");

			var span1 = document.createElement('span');
			span1.innerHTML = " "+myObj[0].video_list[i].title;

			var span2 = document.createElement('span');
			span2.setAttribute("data-toggle", "modal");
			span2.setAttribute("data-target", "#video"+myObj[j].video_list[i].videoid);
			span2.style.float = "right";
			span2.style.color = "black";

			var i2 = document.createElement('i');
			i2.setAttribute("class", "fa fa-eye");
			i2.setAttribute("aria-hidden","true");


			
			/**
			 modalVM
			 */
			var modalVM = document.createElement('div');
			modalVM.setAttribute("class","modal fade");
			modalVM.setAttribute("id", "video" + myObj[j].video_list[i].videoid);
			modalVM.setAttribute("tabindex","-1");
			modalVM.setAttribute("role","dialog");
			modalVM.setAttribute("aria-labelledby","myModalLabel");
			modalVM.setAttribute("aria-hidden","true");

			var modelsub = document.createElement('div');
			modelsub.setAttribute("class","modal-dialog modal-lg");
			modelsub.setAttribute("role", "document");
			

			var Content = document.createElement('div');
			Content.setAttribute("class","modal-content");

			var Body = document.createElement('div');
			Body.setAttribute("class","modal-body mb-0 p-0");

			var subBody = document.createElement('div');
			subBody.setAttribute("class","embed-responsive embed-responsive-16by9 z-depth-1-half");

			var iframe = document.createElement('iframe');
			iframe.setAttribute("src",myObj[j].video_list[i].link);
			iframe.setAttribute("width","640");
			iframe.setAttribute("height", "360");
			iframe.setAttribute("frameborder","0");
			iframe.setAttribute("allow", "autoplay; fullscreen");
			iframe.setAttribute("allowfullscreen", "true");

			

			var footerdiv = document.createElement('div');
			footerdiv.setAttribute("class","modal-footer justify-content-center flex-column flex-md-row"); 

			var footerp = document.createElement('p');
			footerp.innerHTML = myObj[j].video_list[i].title;

			
			subBody.appendChild(iframe);
			Body.appendChild(subBody);

			footerdiv.appendChild(footerp)

			Content.appendChild(Body);
			Content.appendChild(footerdiv)

			modelsub.appendChild(Content);

			modalVM.appendChild(modelsub);



			
			span2.appendChild(i2);
			button.appendChild(i1);
			button.appendChild(span1);
			button.appendChild(span2);
			button.appendChild(modalVM);



			
			

			colldiv3.appendChild(button);

			}

			colldiv2.appendChild(colldiv3);

			colldiv1.append(colldiv2);

			colldiv.appendChild(colldiv1);

			main_lecture_div.appendChild(colldiv);

			
			

			main_div.appendChild(main_lecture_div);

		}


		}
	};
	xmlhttp.open("GET", "json/latest.json", true);
	xmlhttp.send();
}


SetVideoPlayList();



