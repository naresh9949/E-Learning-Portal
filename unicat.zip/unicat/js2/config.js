window._config = {
    cognito: {
        userPoolId: 'us-east-2_0uk0J8GQn', // e.g. us-east-2_uXboG5pAb
        region: 'us-east-2', // e.g. us-east-2
        clientId: '69vnv4955m3iibjlcpp2us7qqp' //is this used anywhere?
    },
};

